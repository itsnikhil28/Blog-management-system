
<?php $__env->startSection('title', $post->title); ?>
<?php $__env->startSection('content'); ?>
    <article class="mb-4">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-md-10 col-lg-8 col-xl-7">
                    <h4><?php echo e($post->content); ?></h4>
                    <p> Posted by <i><?php echo e($post->author); ?></i> on <i><?php echo e(date('d M Y', strtotime($post->published_at))); ?></i>
                    </p>

                    <?php if(Auth::user()->name == $post->author): ?>
                        <div class="d-flex">
                            <a class="btn btn-sm btn-primary text-uppercase" style="text-decoration: none; margin-right: 10px"
                                href="<?php echo e(route('posts.edit', $post->slug)); ?>">Edit Post →</a>
                            <form action="<?php echo e(route('posts.destroy', $post->slug)); ?>" method="POST"
                                onsubmit="return confirm('Are you sure you want to delete this post?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit" class="btn btn-sm btn-danger text-uppercase"
                                    style="text-decoration: none">
                                    Delete Post →
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Blog_Management_System\resources\views/post/singlepost.blade.php ENDPATH**/ ?>