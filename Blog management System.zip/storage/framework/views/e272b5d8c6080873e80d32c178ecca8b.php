<?php $__env->startSection('imagefortitle', 'home-bg.jpg'); ?>
<?php $__env->startSection('title', 'Blog Management System'); ?>
<?php $__env->startSection('subheading', 'A Mini Project'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <!-- Post preview-->
                <?php if(count($posts) > 0): ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="post-preview">
                            <a href="<?php echo e(route('posts.show',$post->slug)); ?>">
                                <h2 class="post-title"><?php echo e($post->title); ?></h2>
                                <h3 class="post-subtitle"><?php echo e(substr($post->content, 0, 30) . '...'); ?></h3>
                            </a>
                            <p class="post-meta">
                                Posted by
                                <a href="javascript:void(0)"><?php echo e($post->author); ?></a>
                                on <?php echo e($post->published_at); ?>

                            </p>
                        </div>
                        <!-- Divider-->
                        <hr class="my-4" />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="post-preview">
                        <h3>No Posts Found</h3>
                        <p>Please create a post to see it here.</p>
                    </div>
                <?php endif; ?>
                
                <!-- Post preview-->
                
                <!-- Pager-->
                <div class="d-flex justify-content-end mb-4">
                    <?php if(Auth::user()): ?>
                        <?php if($posts->count() > 0): ?>
                            <a class="btn btn-primary text-uppercase" href="<?php echo e(route('posts.index')); ?>">All Posts →</a>
                        <?php else: ?>
                            <a class="btn btn-primary text-uppercase" href="<?php echo e(route('posts.create')); ?>">Create Post →</a>
                        <?php endif; ?>
                    <?php else: ?>
                        <a class="btn btn-primary text-uppercase" href="<?php echo e(route('login')); ?>">Login →</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Blog_Management_System\resources\views/welcome.blade.php ENDPATH**/ ?>