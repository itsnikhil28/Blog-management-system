
<?php $__env->startSection('imagefortitle', 'post-bg.jpg'); ?>
<?php $__env->startSection('title', 'Blog Management System'); ?>
<?php $__env->startSection('subheading', 'A Mini Project'); ?>
<?php $__env->startSection('content'); ?>
    <article class="mb-4">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <?php if(session('error')): ?>
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="d-flex justify-content-end">
                    <div class="col-md-4 flex-end">
                        <form action="<?php echo e(route('posts.index')); ?>" method="get">
                            <input type="search" name="search" placeholder="Search..." class="form-control">
                            
                        </form>
                    </div>
                </div>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-10 col-lg-10 col-xl-7">
                        <h2><?php echo e($post->title); ?></h2>
                        <p><?php echo e(substr($post->content, 0, 30)); ?>...

                            <a class="btn btn-sm btn-primary text-uppercase mr-4" style="text-decoration: none"
                                href="<?php echo e(route('posts.show', $post->slug)); ?>">Read More →</a> <br>
                            <?php if(Auth::user()->name == $post->author): ?>
                                <div class="d-flex">
                                    <a class="btn btn-sm btn-primary text-uppercase"
                                        style="text-decoration: none; margin-right: 10px"
                                        href="<?php echo e(route('posts.edit', $post->slug)); ?>">Edit Post →</a>
                                    <form action="<?php echo e(route('posts.destroy', $post->slug)); ?>" method="POST"
                                        onsubmit="return confirm('Are you sure you want to delete this post?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button type="submit" class="btn btn-sm btn-danger text-uppercase"
                                            style="text-decoration: none">
                                            Delete Post →
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>

                        </p>
                    </div>

                    <hr class="my-4 mx-5" />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Blog_Management_System\resources\views/post/post.blade.php ENDPATH**/ ?>