
<?php $__env->startSection('imagefortitle', 'home-bg.jpg'); ?>
<?php $__env->startSection('title', isset($post) ?' Edit Post' : 'Create Post'); ?>
<?php $__env->startSection('subheading', isset($post) ? 'Edit your post' : 'Create a new blog post'); ?>
<?php $__env->startSection('content'); ?>
    <main class="mb-4">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-md-10 col-lg-8 col-xl-7">
                    <div class="my-5">
                        <form
                            <?php if(auth()->guard()->check()): ?> <?php if(isset($post)): ?> action="<?php echo e(route('posts.update', $post->slug)); ?>" <?php else: ?> action="<?php echo e(route('posts.store')); ?>" <?php endif; ?> method="POST" <?php endif; ?>
                            class="d-inline">
                            <?php echo csrf_field(); ?>

                            <?php if(isset($post)): ?>
                            <?php echo method_field('PUT'); ?>
                            <?php endif; ?>
                            <div class="form-floating">
                                <input class="form-control" id="title" name="title" type="text"
                                    placeholder="Enter your title..." data-sb-validations="required"
                                    <?php if(isset($post)): ?> value="<?php echo e($post->title); ?>" <?php endif; ?> />
                                <label for="title">Title</label>
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-floating">
                                <textarea class="form-control" name="content" id="content" placeholder="Enter your content here..."
                                    style="height: 12rem" data-sb-validations="required"><?php if(isset($post)): ?><?php echo e($post->content); ?><?php endif; ?></textarea>
                                <label for="message">Content</label>
                                <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-floating">
                                <input class="form-control" id="author" name="author" type="text"
                                    placeholder="Enter your name..." data-sb-validations="required"
                                    <?php if(Auth::user()): ?> value="<?php echo e(Auth::user()->name); ?>" <?php endif; ?> readonly />
                                <label for="author">Author</label>
                            </div>
                            <br />
                            <div class="d-none" id="submitSuccessMessage">
                                <div class="text-center mb-3">
                                    <div class="fw-bolder">Form submission successful!</div>
                                </div>
                            </div>
                            <div class="d-none" id="submitErrorMessage">
                                <div class="text-center text-danger mb-3">Error sending message!</div>
                            </div>
                            <?php if(auth()->guard()->check()): ?>
                                <button class="btn btn-primary text-uppercase" id="submitButton" type="submit"><?php if(isset($post)): ?> Update <?php else: ?> Create <?php endif; ?></button>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary text-uppercase">Login</a>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Blog_Management_System\resources\views/post/createpost.blade.php ENDPATH**/ ?>